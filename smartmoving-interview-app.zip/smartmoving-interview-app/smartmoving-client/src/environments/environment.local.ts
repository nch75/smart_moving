export const environment = {
  name: 'local',
  production: false,
  apiUrl: 'https://localhost:44308/api',
  reviewPortalUrl: 'http://localhost:9000/?reviewId=',
};
