export const environment = {
  name: 'local',
  production: false,
  apiUrl: 'https://localhost:44308/api',
};
