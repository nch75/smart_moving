

/**
 * By default, zone.js will patch all possible macroTask and DomEvents
 * user can disable parts of macroTask/DomEvents patch by setting following flags
 */

 // (window as any).__Zone_disable_requestAnimationFrame = true; // disable patch requestAnimationFrame
 // (window as any).__Zone_disable_on_property = true; // disable patch onProperty such as onclick
 // (window as any).__zone_symbol__BLACK_LISTED_EVENTS = ['scroll', 'mousemove']; // disable patch specified eventNames

 /*
 * in IE/Edge developer tools, the addEventListener will also be wrapped by zone.js
 * with the following flag, it will bypass `zone.js` patch for IE/Edge
 */
// (window as any).__Zone_enable_cross_context_check = true;

/***************************************************************************************************
 * Zone JS is required by default for Angular itself.
 */
import 'zone.js';  // Included with Angular CLI.
(window as any).global = window;


/***************************************************************************************************
 * APPLICATION IMPORTS
 */
// TODO: Remove when things are fixed upstream (or in the browser?).
// Workaround for Angular issue: https://github.com/angular/angular/issues/35219
// and underlying Chromium bug:https://bugs.chromium.org/p/chromium/issues/detail?id=1049982
(function () {
  const arrayReduce = Array.prototype.reduce;
  let callback;
  Object.defineProperty(Array.prototype, 'reduce', {
      value: function (cb, ...args) {
          callback = cb;
          return arrayReduce.call(this, callback, ...args);
      }
  });
})();

import '@angular/localize/init';
