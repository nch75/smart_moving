export enum YesNoValue {
  Yes = 'Yes',
  No = 'No',
}
