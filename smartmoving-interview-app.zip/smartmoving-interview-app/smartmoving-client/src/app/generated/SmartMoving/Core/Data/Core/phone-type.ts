export enum PhoneType {
  Mobile = 'Mobile',
  Home = 'Home',
  Office = 'Office',
  Other = 'Other',
}
