export enum Permission {
  CompanyDashboard = 5,
  Customers = 25,
  Settings = 150,
}
