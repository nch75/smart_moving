export enum PermissionCategory {
  Modules = 'Modules',
}
