export enum DecimalRounding {
  MidpointAwayFromZero = 'MidpointAwayFromZero',
  Up = 'Up',
  Down = 'Down',
}
