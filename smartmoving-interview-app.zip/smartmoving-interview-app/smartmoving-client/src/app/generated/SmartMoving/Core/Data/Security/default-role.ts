export enum DefaultRole {
  Admin = 'Admin',
}
