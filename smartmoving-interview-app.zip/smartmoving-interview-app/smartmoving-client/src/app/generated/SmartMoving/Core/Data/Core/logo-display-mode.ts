export enum LogoDisplayMode {
  Portrait = 'Portrait',
  Landscape = 'Landscape',
}
