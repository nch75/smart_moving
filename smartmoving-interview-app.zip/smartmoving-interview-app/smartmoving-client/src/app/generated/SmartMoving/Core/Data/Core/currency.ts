export enum Currency {
  USD = 'USD',
  CAD = 'CAD',
}
