export class SelectListOption {
  id: string;
  name: string;
}
