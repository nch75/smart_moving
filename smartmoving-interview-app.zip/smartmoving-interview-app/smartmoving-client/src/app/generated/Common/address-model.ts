export class AddressModel {
  street: string;
  city: string;
  state: string;
  zipCode: string;
  fullAddress: string;
}
