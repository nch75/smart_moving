export class SelectListDecimalOption {
  id: number;
  name: string;
}
