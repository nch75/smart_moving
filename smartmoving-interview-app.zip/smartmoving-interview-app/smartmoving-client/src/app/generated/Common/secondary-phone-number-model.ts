import { PhoneType } from '../SmartMoving/Core/Data/Core/phone-type';
export class SecondaryPhoneNumberModel {
  phoneNumber: string;
  phoneType?: PhoneType;
}
