export class AppUserSummaryViewModel {
  id: string;
  displayName: string;
  email: string;
  phoneNumber: string;
  title: string;
  displayTitle: string;
}
