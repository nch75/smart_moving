export class BadRequestModel {
  message: string;
}
