export class CustomerSummaryViewModel {
  id: string;
  createdAtUtc: string;
  name: string;
  emailAddress: string;
  hasAccount: boolean;
}
