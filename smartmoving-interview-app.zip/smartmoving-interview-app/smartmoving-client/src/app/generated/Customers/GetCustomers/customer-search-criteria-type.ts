export enum CustomerSearchCriteriaType {
  Name = 'Name',
  HasAccount = 'HasAccount',
  EmployeeNumber='EmployeeNumber'
}
