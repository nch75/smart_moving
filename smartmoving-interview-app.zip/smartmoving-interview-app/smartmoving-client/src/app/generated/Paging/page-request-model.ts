export class PageRequestModel {
  page: number;
  pageSize: number;
  sort: string;
}
