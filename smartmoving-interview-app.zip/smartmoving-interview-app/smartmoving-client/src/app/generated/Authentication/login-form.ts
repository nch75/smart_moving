export class LoginForm {
  emailAddress: string;
  password: string;
  rememberMe: boolean;
}
