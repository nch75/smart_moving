import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sm-settings-home',
  templateUrl: './settings-home.component.html',
})
export class SettingsHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
