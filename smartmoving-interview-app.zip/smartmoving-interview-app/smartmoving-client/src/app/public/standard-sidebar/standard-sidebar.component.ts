import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sm-standard-sidebar',
  templateUrl: './standard-sidebar.component.html',
  styleUrls: ['./standard-sidebar.component.scss']
})
export class StandardSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
