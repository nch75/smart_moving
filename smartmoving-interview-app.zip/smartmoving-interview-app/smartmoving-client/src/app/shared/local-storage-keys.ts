export const LocalStorageKeys = {
  BRANCH: 'SmartMoving.Branch',
  CURRENT_USER: 'SmartMoving.CurrentUser',
};
