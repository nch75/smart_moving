﻿export interface SlideoutWithCustomDismissedResult {
  getSlideoutDismissedResult(): any;
}
