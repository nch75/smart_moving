import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { LocalStorageKeys } from 'app/shared/local-storage-keys';

@Component({
  selector: 'sm-app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.scss']
})
export class AppHeaderComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
