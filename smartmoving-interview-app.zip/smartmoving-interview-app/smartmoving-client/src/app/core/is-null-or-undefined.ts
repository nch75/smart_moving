export function isNullOrUndefined(obj: any) {
  return obj === null || obj === undefined;
}
