export const trackById = (index: number, obj: { id: string }) => obj && obj.id;
