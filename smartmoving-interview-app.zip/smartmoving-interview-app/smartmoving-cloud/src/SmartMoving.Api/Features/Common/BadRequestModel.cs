﻿namespace SmartMoving.Api.Features.Common
{
    public class BadRequestModel
    {
        public string Message { get; set; }
    }
}