namespace SmartMoving.Api.Features.Customers.GetCustomers
{
    public enum CustomerSearchCriteriaType
    {
        Name,
        HasAccount,
        EmployeeNumber
    }
}