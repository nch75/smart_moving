﻿using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartMoving.Api.Features.Common;
using SmartMoving.Api.Features.Customers.Common;
using SmartMoving.Api.Features.Customers.GetCustomers;
using SmartMoving.Api.Infrastructure;
using SmartMoving.Core.Data.Core;
using SmartMoving.Core.Extensions;
using SmartMoving.Data;
using SmartMoving.Data.Contexts;

namespace SmartMoving.Api.Features.Customers.AddCustomerController
{
    [StandardRoute("customers"),
     Authorize,
     ApiController]
    public class AddCustomerController : SmartMovingController
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public AddCustomerController(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpPut]
        public async Task<ActionResult<CustomerDetailsViewModel>>AddCustomer(AddCustomerForm form)
        {
           
            var target =  _mapper.Map<Customer>(form);

            target.Id = Guid.NewGuid();
            target.EmailAddress = target.EmailAddress.TrimSafe();
            target.EmployeeNumber = target.EmployeeNumber.TrimSafe();
            target.NormalizePhoneNumbers();

            //Necessary because EF doesn't recognize changes to fields that have a 
            //conversion function specified, like SecondaryPhoneNumbers. 
            await _context.Customers.AddAsync(target); ;

            await _context.SaveChangesAsync();

            var result = await _context.Customers
                                       .Where(x => x.Id == target.Id)
                                       .ProjectTo<CustomerDetailsViewModel>(_mapper.ConfigurationProvider)
                                       .SingleAsync();

            return Ok(result);
        }
    }
}