﻿using SmartMoving.Api.Infrastructure.Startup;
using SmartMoving.Core.Data.Core;
using System.ComponentModel.DataAnnotations;
using System;

namespace SmartMoving.Api.Features.Customers.AddCustomerController
{
    public class AddCustomerForm : IMapTo<Customer>
    {
        [Required]
        public string Name { get; set; }

        public string PhoneNumber { get; set; }

        public PhoneType? PhoneType { get; set; }

        [EmailAddress]
        public string EmailAddress { get; set; }

        public string Address { get; set; }

        [Required]
        public string EmployeeNumber { get; set; }

        public SecondaryPhoneNumber[] SecondaryPhoneNumbers { get; set; } = Array.Empty<SecondaryPhoneNumber>();
    }
}