using System;

namespace SmartMoving.Core
{
    public class ExportEnumAsIntegerAttribute : Attribute
    {
        
    }
}