﻿namespace SmartMoving.Core.Data.Core
{
    public enum PhoneType
    {
        Mobile,
        Home,
        Office,
        Other
    }
}