﻿namespace SmartMoving.Core.Data.Core.CompanySettingTypes
{
    public class SocialMediaSettings
    {
        public string GoogleUrl { get; set; }

        public string YelpUrl { get; set; }

        public string FacebookUrl { get; set; }

        public string AngiesListUrl { get; set; }
    }
}