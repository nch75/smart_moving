namespace SmartMoving.Core.Data.Core
{
    public enum Currency
    {
        USD,
        CAD
    }
}
