﻿namespace SmartMoving.Core.Data.Core
{
    // This type is stored as JSON data
    public class SecondaryPhoneNumber
    {
        public string PhoneNumber { get; set; }

        public PhoneType? PhoneType { get; set; }
    }
}
