﻿namespace SmartMoving.Data.Contexts
{
    public enum QueryFilters
    {
        Company,
        IBelongToCompany
    }
}
