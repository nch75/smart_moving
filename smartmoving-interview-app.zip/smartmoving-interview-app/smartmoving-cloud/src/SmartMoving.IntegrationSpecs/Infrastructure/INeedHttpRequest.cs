﻿namespace SmartMoving.IntegrationSpecs.Infrastructure
{
    public interface INeedHttpRequest : INeedControllerPropertiesMocked
    {
    }
}
