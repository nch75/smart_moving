﻿using SpecsFor.Core;

namespace SmartMoving.IntegrationSpecs.Infrastructure
{
    public interface INeedControllerPropertiesMocked : ISpecs
    {
    }
}
