Welcome to the SmartMoving interview sample app!

To get started, check out the more specific READMEs for each of the projects.

When you are finished, prepare a feature branch (named "features/{firstname}-{lastname}/interview-challenge") with your changes and commit (as you would prior to opening a pull request).

When you are finished with all tasks, please run:

- CleanBinObj.bat (this removes all the built binaries)
- Go to the smartmoving-client folder, and run `npm run clean` (this removes all the downloaded node packages)
    - Note: this may error about "folder not found", but that should be for the "dist" folder, which may or may not
      exist for you.

After that, compress the folder and send it back to us! It should be around 3 MB or less. If it's notably larger, something didn't clean up correctly, so please check that.
